//
//  ViewController.swift
//  Shoping
//
//  Created by mjeed on 29/11/2023.
//

import UIKit

class SignInVC: UIViewController {
    // MARK: - Outlets
    @IBOutlet  var mainView: [UIView]!
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var loginButton: UIButton!

    
    // MARK: - Variables

    
    
    
    // MARK: - View Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        configurView()

    }
    
    // MARK: -  Configure Action - Func
    
   private func configurView() {
       
       loginButton.addCornerRadius(radius: 20)
        for border in [emailTextField , passwordTextField] {
            border?.addBorder(color: Colors.CE6E6E6, with: 0.7)
            border?.addCornerRadius(radius: 20)
        }
       
       for itme in mainView {
           itme.addCornerRadius(radius: 24)
       }
       
    }


}

