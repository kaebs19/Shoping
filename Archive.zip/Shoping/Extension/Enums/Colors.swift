//
//  Colors.swift
//  Shoping
//
//  Created by mjeed on 29/11/2023.
//

import UIKit

enum Colors: String {
    case CFFFFFF = "#FFFFFF"
    case CE6E6E6 = "#E6E6E6"
    case C00CBFF = "#00CBFF"
}
